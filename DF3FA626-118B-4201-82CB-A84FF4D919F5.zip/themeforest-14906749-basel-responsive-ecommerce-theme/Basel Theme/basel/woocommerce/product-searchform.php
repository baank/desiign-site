<?php
/**
 * The template for displaying product search form
 *
 * @see     http://docs.woothemes.com/document/template-structure/
 * @package WooCommerce/Templates
 * @version 2.5.0
 */

basel_header_block_search_extended(); ?>